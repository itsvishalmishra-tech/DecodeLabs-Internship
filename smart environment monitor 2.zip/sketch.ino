#include <DHT.h>
#include <LiquidCrystal_I2C.h>
#include <Servo.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define DHTPIN 2
#define DHTTYPE DHT22

#define BUZZER 8
#define RED 9
#define GREEN 10
#define BLUE 11
#define LDR A1

DHT dht(DHTPIN, DHTTYPE);

LiquidCrystal_I2C lcd(0x27,16,2);

Servo myServo;

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

void setup() {

  dht.begin();

  lcd.init();
  lcd.backlight();

  pinMode(BUZZER,OUTPUT);

  pinMode(RED,OUTPUT);
  pinMode(GREEN,OUTPUT);
  pinMode(BLUE,OUTPUT);

  myServo.attach(6);

  display.begin(SSD1306_SWITCHCAPVCC,0x3C);

  Serial.begin(9600);
}

void loop() {

  float temp = dht.readTemperature();
  float hum = dht.readHumidity();
  int light = analogRead(LDR);

  // LCD
  lcd.clear();
  lcd.setCursor(0,0);
  lcd.print("Temp:");
  lcd.print(temp);

  lcd.setCursor(0,1);
  lcd.print("Hum:");
  lcd.print(hum);

  // OLED
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);

  display.setCursor(0,0);
  display.print("Temperature:");
  display.print(temp);
  display.println(" C");

  display.print("Humidity:");
  display.print(hum);
  display.println("%");

  display.print("Light:");
  display.println(light);

  display.display();

  // RGB LED
  if(temp < 30)
  {
    digitalWrite(GREEN,HIGH);
    digitalWrite(RED,LOW);
    digitalWrite(BLUE,LOW);

    noTone(BUZZER);
    myServo.write(0);
  }

  else if(temp >= 30 && temp <= 35)
  {
    digitalWrite(BLUE,HIGH);
    digitalWrite(GREEN,LOW);
    digitalWrite(RED,LOW);

    noTone(BUZZER);
    myServo.write(45);
  }

  else
  {
    digitalWrite(RED,HIGH);
    digitalWrite(GREEN,LOW);
    digitalWrite(BLUE,LOW);

    tone(BUZZER,1000);
    myServo.write(90);
  }

  Serial.print("Temp = ");
  Serial.print(temp);
  Serial.print("  Hum = ");
  Serial.print(hum);
  Serial.print("  Light = ");
  Serial.println(light);

  delay(2000);
}